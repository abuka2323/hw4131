CREATE TABLE auction (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    image_url VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    category VARCHAR(50) NOT NULL,
    end_date DATETIME NOT NULL
);

CREATE TABLE bid (
    id INT AUTO_INCREMENT PRIMARY KEY,
    auction_id INT NOT NULL,
    bidder_name VARCHAR(255) NOT NULL,
    bid_amount DECIMAL(10, 2) NOT NULL,
    comment TEXT,
    FOREIGN KEY (auction_id) REFERENCES auction(id) ON DELETE CASCADE
);
