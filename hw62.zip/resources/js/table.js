document.addEventListener("DOMContentLoaded", () => {
    const rows = document.querySelectorAll(".listing-row");
    const previewContainer = document.getElementById("preview-content");

    rows.forEach((row) => {
        row.addEventListener("mouseenter", () => {
            const imageUrl = row.getAttribute("data-image");
            const description = row.getAttribute("data-description");

            previewContainer.innerHTML = `
                <img src="/images/${imageUrl}" alt="Preview Image" style="width: 200px; height: auto;">
                <p>${description}</p>
            `;
        });

        row.addEventListener("mouseleave", () => {
            previewContainer.innerHTML = `<p>Hover over a listing to see its preview here.</p>`;
        });
    });

    const deleteButtons = document.querySelectorAll(".delete-button");
    deleteButtons.forEach(button => {
        button.addEventListener("click", function() {
            const row = button.closest("tr");
            const listingId = row.getAttribute("data-listing-id");

            fetch("/api/delete_listing", {
                method: "DELETE",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({ listing_id: parseInt(listingId) })
            })
            .then(response => {
                if (response.status === 204 || response.status === 404) {
                    row.remove();
                } else if (response.status === 400 || response.status === 500) {
                    alert("An error occurred while deleting the listing.");
                }
            })
            .catch(error => {
                console.error("Error:", error);
                alert("An error occurred while deleting the listing.");
            });
        });
    });
});
